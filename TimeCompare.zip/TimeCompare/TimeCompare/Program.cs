﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
namespace TimeCompare
{

    public struct XYCoord
    {
        public double x;
        public double y;
    }

    class Program
    {
        [DllImport(@"..\..\..\Release\FromDLL.dll", EntryPoint = "fastUtmToLL")]
        public static extern XYCoord fastUtmToLL(double x, double y, int zone);
        [DllImport("kernel32.dll")]
        public static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        [DllImport("kernel32.dll")]
        public static extern bool QueryPerformanceFrequency(out long lpPerformanceFreq);
        public const double FALSE_EASTING = 500000.0;
        public static XYCoord clrUtmToLL(double x, double y, int zone)
        {
            double k0 = 0.9996;
            double equitorialRadius = 6378137.0;
            double eccSq = 0.006694380023;
            double eccPrimeSq = eccSq / (1 - eccSq);
            double r2d = 180.0 / Math.PI;
            double e1 = (1 - Math.Sqrt(1 - eccSq)) / (1 + Math.Sqrt(1 - eccSq));

            double xUTM = x - (FALSE_EASTING);
            double yUTM = y;
            int longOrig = (zone - 1) * 6 - 180 + 3;
            double M = yUTM / k0;
            double mu = M / (equitorialRadius * (1 - eccSq / 4 - 3 * eccSq * eccSq / 64 - 5 * eccSq * eccSq * eccSq / 256));
            double phi1Rad = mu + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * Math.Sin(2 * mu) + (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * Math.Sin(4 * mu) + (151 * e1 * e1 * e1 / 96) * Math.Sin(6 * mu);
            double phi1 = phi1Rad * r2d;
            double N1 = equitorialRadius / Math.Sqrt(1 - eccSq * Math.Sin(phi1Rad) * Math.Sin(phi1Rad));
            double T1 = Math.Tan(phi1Rad) * Math.Tan(phi1Rad);
            double C1 = eccPrimeSq * Math.Cos(phi1Rad) * Math.Cos(phi1Rad);
            double R1 = equitorialRadius * (1 - eccSq) / Math.Pow(1 - eccSq * Math.Sin(phi1Rad) * Math.Sin(phi1Rad), 1.5);
            double D = xUTM / (N1 * k0);

            double lat = phi1Rad - (N1 * Math.Tan(phi1Rad) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * eccPrimeSq) * D * D * D * D / 24 + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * eccPrimeSq - 3 * C1 * C1) * D * D * D * D * D * D / 720);
            double lon = (D - (1 + 2 * T1 + C1) * D * D * D / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * eccPrimeSq + 24 * T1 * T1) * D * D * D * D * D / 120) / Math.Cos(phi1Rad);

            XYCoord retVal;

            lat = lat * r2d;
            lon = longOrig + lon * r2d;

            retVal.x = lat;
            retVal.y = lon;
            return retVal;
        }

        static void Main(string[] args)
        {
            double[] rnd = new double[2000];
            long freq, startCS, endCS, startC, endC;
            QueryPerformanceFrequency(out freq);
            Random r = new Random();
            XYCoord retVal;
            for (int i = 0; i < 2000; i++)
            {
                rnd[i] = r.NextDouble();
            }
            QueryPerformanceCounter(out startCS);
            for (int i = 0; i < 100000000; i++)
            {
                retVal = clrUtmToLL(rnd[(i % 1000)], rnd[(i % 1000) + 999], 10);
            }
            QueryPerformanceCounter(out endCS);
            QueryPerformanceCounter(out startC);
            for (int i = 0; i < 100000000; i++)
            {
                retVal = fastUtmToLL(rnd[(i % 1000)], rnd[(i % 1000) + 999], 10);
            }
            QueryPerformanceCounter(out endC);
            double secondsCS = (((endCS - startCS) / (double)freq));
            double secondsC = (endC - startC) / (double)freq;
            Console.WriteLine("C# function calls took " + secondsCS.ToString() + " seconds to complete.");
            Console.WriteLine("C function calls took " + secondsC.ToString() + " seconds to complete.");

        }
    }
}
