#define FALSE_EASTING 500000.0
#define _USE_MATH_DEFINES
#include <math.h>

/**
 * Return type of the fastUtmToLL function (mirrored in the C# function that calls the DLL function)
 */
typedef struct _xycoord
{
	double x;
	double y;
} xycoord;

// Converts UTM coordinates to conventional latitude and longitude coordinates (WGS84)
// x = UTM-X coordinate
// y = UTM-Y coordinate
// zone = UTM band
xycoord __stdcall fastUtmToLL(double x, double y, int zone)
{
	const double k0 = 0.9996;
	const double equitorialRadius = 6378137.0;
	const double eccSq = 0.006694380023;
	const double eccPrimeSq = eccSq / (1 - eccSq);
	const double r2d = 180.0 / M_PI;
	const double e1 = (1 - sqrt(1 - eccSq)) / (1 + sqrt(1 - eccSq));

	double xUTM = x - (FALSE_EASTING);
	double yUTM = y;
	int longOrig = (zone - 1) * 6 - 180 + 3;
	double M = yUTM / k0;
	double mu = M / (equitorialRadius * (1 - eccSq / 4 - 3 * eccSq * eccSq / 64 - 5 * eccSq * eccSq * eccSq / 256));
	double phi1Rad = mu + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * sin(2 * mu) + (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * sin(4 * mu) + (151 * e1 * e1 * e1 / 96) * sin(6 * mu);
	double phi1 = phi1Rad * r2d;
	double N1 = equitorialRadius / sqrt(1 - eccSq * sin(phi1Rad) * sin(phi1Rad));
	double T1 = tan(phi1Rad) * tan(phi1Rad);
	double C1 = eccPrimeSq * cos(phi1Rad) * cos(phi1Rad);
	double R1 = equitorialRadius * (1 - eccSq) / pow(1 - eccSq * sin(phi1Rad) * sin(phi1Rad), 1.5);
	double D = xUTM / (N1 * k0);

	double lat = phi1Rad - (N1 * tan(phi1Rad) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * eccPrimeSq) * D * D * D * D / 24 + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * eccPrimeSq - 3 * C1 * C1) * D * D * D * D * D * D / 720);
	double lon = (D - (1 + 2 * T1 + C1) * D * D * D / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * eccPrimeSq + 24 * T1 * T1) * D * D * D * D * D / 120) / cos(phi1Rad);

	xycoord retVal;

	lat = lat * r2d;
	lon = longOrig + lon * r2d;

	retVal.x = lat;
	retVal.y = lon;
	return retVal;
}